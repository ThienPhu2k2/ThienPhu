function validate() {
    var ten = document.getElementById("username").value;
    var sub = document.getElementById("sub").value;
    var mas = document.getElementById("mas").value;
    var e = document.getElementById("email").value;
     
    if(ten == "") {
        alert("Vui lòng không bỏ trống!");
        return false;
    }

    if(sub == "") {
        alert("Vui lòng nhập không bỏ trống!");
        return false;
    }
    
    if(mas == "") {
        alert("Vui lòng không bỏ trống!");
        return false;
    }
    
    var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if(e == "") {
        alert("Vui lòng nhập email!");
        return false;
    }
    else if(!mailformat.test(e)){
        alert("sai định dạng email!");
        return false;
    }
    alert("Đã nhận được tin")
    return true;
}