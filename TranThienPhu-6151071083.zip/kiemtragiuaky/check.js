function validate() {
    var ten = document.getElementById("username").value;
    var mk = document.getElementById("password").value;
    var rmk = document.getElementById("password-repeat").value;
    var e = document.getElementById("email").value;
     
    if(ten == "") {
        alert("Vui lòng nhập tên!");
    return false;
    }
    else if(ten.length < 6){
        alert("Tên đăng nhập phải dài hơn 6 ký tự")
    return false;
    }

    if(mk == "") {
        alert("Vui lòng nhập mật khẩu!");
    return false;
    }
    else if(mk.length < 6){
        alert("Mật khấu phải dài hơn 6 ký tự")
    return false;
    }
    
    if(rmk == "") {
        alert("Vui lòng xác minh mật khẩu!");
    return false;
    }
    else if(rmk != mk){
        alert("Sai mặt khẩu!");
    return false;
    }
    
    var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if(e == "") {
    alert("Vui lòng nhập email!");
    return false;
    }
    else if(!mailformat.test(email)){
        alert("sai định dạng email!");
        return false;
    }
    return true;
    }