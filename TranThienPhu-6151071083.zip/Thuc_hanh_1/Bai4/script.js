function validate() {
    var search = document.getElementById("search").value;
    var email = document.getElementById("email").value;
    var rating = document.getElementById("rate").value;
    var cmt = document.getElementById("com").value;
     
    if(search == '') {
        alert("Vui lòng không bỏ trống!");
        return false;
    }

    if(rating == ''){
        alert("vui lòng không bỏ trống!");
        return false;
    }
    else if(rating != '' && !/^[0-9]{10}$/.test(rating)){
        alert("Rating phải là số");
        return false;
    }

    if(cmt != '' && cmt.length < 30){
        alert("Validate comment điền ít nhất 30 ký tự trở lên");
        return false;
    }
    
    var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if(email == "") {
        alert("Vui lòng nhập email!");
        return false;
    }
    else if(!mailformat.test(email)){
        alert("sai định dạng email!");
        return false;
    }

    return true;
    }