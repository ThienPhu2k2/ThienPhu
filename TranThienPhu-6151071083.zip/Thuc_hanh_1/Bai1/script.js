function validate() {
    var key = document.getElementById("key").value;
    var form = document.getElementById("from").value;
    var to = document.getElementById("to").value;
     
    if(key == "") {
        alert("Vui lòng nhập tên cần kiếm!");
    return false;
    }

    if(from != '' &&  !/^[0-9]{10}$/.test(from)) {
        alert("Vui lòng xem lại validate!");
    return false;
    }

    if(to != '' &&  !/^[0-9]{10}$/.test(to)) {
        alert("Vui lòng xem lại validate!");
    return false;
    }

    return true;
    }