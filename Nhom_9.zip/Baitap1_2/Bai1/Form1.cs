﻿using System.Collections;
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using System.Security.Policy;

namespace Bai1
{
    public partial class Form1 : Form
    {
        DataTable orderTable = new DataTable();

        public Form1()
        {
            InitializeComponent();

            dataGridView1.DataSource = orderTable;
            orderTable.Columns.Add("FoodName");
            orderTable.Columns.Add("Quantity");
            dataGridView1.Columns["FoodName"].Width = 160;
            dataGridView1.Columns["Quantity"].Width = 160;
        }

        private void add(string food = "")
        {

            if (string.IsNullOrEmpty(food))
                return;

            DataRow newRow = orderTable.NewRow();
            foreach (DataRow row in orderTable.Rows)
            {
                if (row["FoodName"].ToString() == food)
                {
                    int.TryParse(row["Quantity"].ToString(), out int n);
                    row["Quantity"] = n + 1;
                    return;
                }
            }

            newRow["FoodName"] = food;
            newRow["Quantity"] = "1";
            orderTable.Rows.Add(newRow);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            add((sender as Button)?.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("Chưa chọn món!");
                return;
            }
            if (string.IsNullOrEmpty(comboBox1.SelectedItem?.ToString()))
            {
                MessageBox.Show("Chưa chọn bàn!");
                return;
            }
            MessageBox.Show("Oder thành công.");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow item in this.dataGridView1.SelectedRows)
            {
                dataGridView1.Rows.RemoveAt(item.Index);
            }
        }

        private void findBtn_Click(object sender, EventArgs e)
        {
            var rowList = dataGridView1.Rows;
            int index = 0;

            for (int i = 0; i < rowList.Count; i++)
            {
                if (rowList[i].Cells["FoodName"].Value.ToString()?.ToLower() == foodInput.Text)
                {
                    dataGridView1.CurrentCell = rowList[i - 1].Cells["FoodName"];
                    dataGridView1.CurrentCell = rowList[i].Cells["FoodName"];

                    index++;

                    rowList[i].Selected = true;
                    break;
                }
            }
            if(index <= 0)
            {
                MessageBox.Show("Món này chưa được oder");
                return;
            }
        }

        private void foodInput_TextChanged(object sender, EventArgs e)
        {

        }
    }

}