﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baitap3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            if (listView3.SelectedItems.Count > 0)
            {
                listView3.Items.Remove(listView3.SelectedItems[0]);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView3.View = View.Details;
            listView3.GridLines = true;
            listView3.FullRowSelect = true;
        }

        private void btThem_Click(object sender, EventArgs e)
        {
            ListViewItem lvi = listView3.Items.Add(textBox1.Text);
            lvi.SubItems.Add(dateTimePicker1.Value.ToShortDateString());
            lvi.SubItems.Add(textBox3.Text);
            lvi.SubItems.Add(textBox2.Text);

            if (listView3.SelectedItems.Count > 0)
            {
                textBox1.Text = listView3.SelectedItems[0].SubItems[0].Text;

                dateTimePicker1.Text = listView3.SelectedItems[0].SubItems[1].Text;

                textBox3.Text = listView3.SelectedItems[0].SubItems[2].Text;

                textBox2.Text = listView3.SelectedItems[0].SubItems[3].Text;

            }
        }

        private void btSua_Click(object sender, EventArgs e)
        {
            if (listView3.SelectedItems.Count > 0)
            {
                listView3.SelectedItems[0].SubItems[0].Text = textBox1.Text;
                listView3.SelectedItems[0].SubItems[1].Text = dateTimePicker1.Value.ToShortDateString();

                listView3.SelectedItems[0].SubItems[2].Text = textBox3.Text;

                listView3.SelectedItems[0].SubItems[3].Text = textBox2.Text;
            }
        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView3.SelectedItems.Count>0)
            {
                textBox1.Text = listView3.SelectedItems[0].SubItems[0].Text;
                dateTimePicker1.Text = listView3.SelectedItems[0].SubItems[1].Text;
                textBox3.Text = listView3.SelectedItems[0].SubItems[2].Text;
                textBox2.Text = listView3.SelectedItems[0].SubItems[3].Text; 
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
