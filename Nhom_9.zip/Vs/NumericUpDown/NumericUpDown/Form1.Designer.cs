﻿namespace NumericUpDown
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTittle = new System.Windows.Forms.Label();
            this.lblText1 = new System.Windows.Forms.Label();
            this.lblText2 = new System.Windows.Forms.Label();
            this.nmrud = new System.Windows.Forms.NumericUpDown();
            this.tb = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nmrud)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTittle
            // 
            this.lblTittle.AutoSize = true;
            this.lblTittle.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTittle.ForeColor = System.Drawing.Color.YellowGreen;
            this.lblTittle.Location = new System.Drawing.Point(141, 25);
            this.lblTittle.Name = "lblTittle";
            this.lblTittle.Size = new System.Drawing.Size(547, 38);
            this.lblTittle.TabIndex = 0;
            this.lblTittle.Text = "NumericUpDown     Control Sample";
            // 
            // lblText1
            // 
            this.lblText1.AutoSize = true;
            this.lblText1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblText1.Location = new System.Drawing.Point(143, 141);
            this.lblText1.Name = "lblText1";
            this.lblText1.Size = new System.Drawing.Size(130, 26);
            this.lblText1.TabIndex = 1;
            this.lblText1.Text = "Select Value:";
            // 
            // lblText2
            // 
            this.lblText2.AutoSize = true;
            this.lblText2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblText2.Location = new System.Drawing.Point(143, 233);
            this.lblText2.Name = "lblText2";
            this.lblText2.Size = new System.Drawing.Size(152, 26);
            this.lblText2.TabIndex = 2;
            this.lblText2.Text = "Selected Value:";
            // 
            // nmrud
            // 
            this.nmrud.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nmrud.Location = new System.Drawing.Point(405, 141);
            this.nmrud.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nmrud.Name = "nmrud";
            this.nmrud.Size = new System.Drawing.Size(210, 22);
            this.nmrud.TabIndex = 3;
            this.nmrud.ValueChanged += new System.EventHandler(this.nmrud_ValueChanged);
            // 
            // tb
            // 
            this.tb.Location = new System.Drawing.Point(405, 233);
            this.tb.Name = "tb";
            this.tb.Size = new System.Drawing.Size(210, 22);
            this.tb.TabIndex = 4;
            this.tb.TextChanged += new System.EventHandler(this.tb_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tb);
            this.Controls.Add(this.nmrud);
            this.Controls.Add(this.lblText2);
            this.Controls.Add(this.lblText1);
            this.Controls.Add(this.lblTittle);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nmrud)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTittle;
        private System.Windows.Forms.Label lblText1;
        private System.Windows.Forms.Label lblText2;
        private System.Windows.Forms.NumericUpDown nmrud;
        private System.Windows.Forms.TextBox tb;
    }
}

