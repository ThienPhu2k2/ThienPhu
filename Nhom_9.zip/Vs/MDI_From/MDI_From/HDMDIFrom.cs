﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDI_From
{
    public partial class HDMDIFrom : Form
    {
        public HDMDIFrom()
        {
            InitializeComponent();
        }
    }
}
