﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGridView
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable("People");

            dt.Columns.Add("First Name",
            System.Type.GetType("System.String"));
            dt.Columns.Add("Last Name",
            System.Type.GetType("System.String"));
            dt.Columns.Add("Occupation",
            System.Type.GetType("System.String"));
            dt.Columns.Add("Salary",
            System.Type.GetType("System.Int32"));

            dt.Rows.Add(new object[]
                {"Rod", "Stephens", "Nerd", 10000});
            dt.Rows.Add(new object[]
                {"Sergio", "Aragones", "Cartoonist", 20000});
            dt.Rows.Add(new object[]
                {"Eoin", "Colfer", "Author", 30000});
            dt.Rows.Add(new object[]
                {"Jerry", "Pratchett", "Author", 40000});

            dataGridView.DataSource = dt;
        }
    }
}
