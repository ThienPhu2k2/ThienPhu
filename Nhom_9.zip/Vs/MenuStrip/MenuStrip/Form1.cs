﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenuStrip
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void menuItem1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void menuItem1ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bạn đã nhấp vào MenuItem_1");
        }

        private void menuItem2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bạn đã nhấp vào MenuItem_2");
        }
    }
}
