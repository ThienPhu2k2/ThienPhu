﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Program
    {
        void chuoinguoc()
        {
            Console.Write("Nhap chuoi bat ky : ");
            string str = Console.ReadLine();
            string answer = string.Empty;
            for (int i = str.Length - 1; i >= 0; i--)
            {
                answer += str[i];
            }
            Console.WriteLine("\nChuoi dao nguoc tu chuoi '{0}' la: {1}", str, answer);
        }

        void KiemtraPass()
        {
            int count = 0;
            do
            {
                Console.Write("Nhap username: ");
                string username = Console.ReadLine();
                Console.Write("\nNhap password: ");
                string pass = Console.ReadLine();
                Console.WriteLine("");
                if (pass != "123" || username != "k61")
                {
                    count++;
                }
                else
                {
                    count = -1;
                }
            } while (count >= 0 && count < 3);
            if (count >= 3)
            {
                Console.WriteLine("Nhap sai qua 3 lan !!");
            }
            else
            {
                Console.WriteLine("Dang nhap thanh cong !!");
            }
        }

        void giaiPhuongTrinhBac2()
        {
            double a, b, c;
            Console.WriteLine("Phuong trinh bac hai ax^2 + bx + c ");
            Console.Write("Nhap a = ");
            a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Nhap b = ");
            b = Convert.ToDouble(Console.ReadLine());
            Console.Write("Nhap c = ");
            c = Convert.ToDouble(Console.ReadLine());

            double x, x1, x2;
            double delta = b * b - 4 * a * c;
            if (a == 0)
            {
                if (b == 0)
                {
                    Console.WriteLine("Phuong trinh vo nghiem");
                    Console.ReadLine();

                }
                else
                {
                    Console.WriteLine("Phuong trinh co mot nghiem duy nhat la: " + (-c / b));
                    Console.ReadLine();
                }
                return;
            }
            else
            {
                if (delta == 0)
                {
                    x = (-b / 2 * a);
                    Console.WriteLine("Phuong trinh co nghiem kep x = " + x);
                    Console.ReadLine();
                }
                else if (delta < 0)
                {
                    Console.WriteLine("Phuong trinh vo nghiem");
                    Console.ReadLine();

                }
                else
                {
                    x1 = (-b + Math.Sqrt(delta)) / 2 * a;
                    x2 = (-b - Math.Sqrt(delta)) / 2 * a;

                    Console.WriteLine("Phuong trinh co 2 nghiem phan biet x1= {0}, x2 = {1 }", x1, x2);
                    Console.ReadLine();
                }

            }
        }

        double DienTichCN(double a, double b)
        {
            return a * b;
        }
        double DienTichTron(double r)
        {
            double pi = 3.14159;
            return pi * r * r;
        }
        double DienTichTamGiac(double a, double b, double c)
        {
            double p = (a + b + c) / 2;
            return Math.Sqrt(p * (p - a) * (p - b) * (p - c));

        }
        void menuDienTich()
        {
            int Chon;
            Console.WriteLine("--------------- MENU ---------------");
            Console.WriteLine("| 1. Tinh Dien Tich Hinh Chu Nhat. |");
            Console.WriteLine("| 2. Tinh Dien Tich Hinh Tron.     |");
            Console.WriteLine("| 3. Tinh Dien Tich Hinh Tam Giac. |");
            Console.WriteLine("| 4. Thoat.                        |");
            Console.WriteLine("------------------------------------");
            do
            {
                Console.Write("Nhap lua chon : ");
                Chon = Convert.ToInt16(Console.ReadLine());
                switch (Chon)
                {
                    case 1:
                        Console.Write("Nhap Chieu Dai la:");
                        double d = Convert.ToDouble(Console.ReadLine());
                        Console.Write("\nNhap Chieu rong:");
                        double r = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("\nDien Tich hinh chu nhat la:{0}", DienTichCN(d, r));
                        break;
                    case 2:
                        Console.Write("Nhap ban kinh la:");
                        double r1 = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("\nDien Tich hinh tron la:{0}", DienTichTron(r1));
                        break;
                    case 3:
                        Console.Write("Nhap canh a:");
                        double a1 = Convert.ToDouble(Console.ReadLine());
                        Console.Write("\nNhap canh b:");
                        double b1 = Convert.ToDouble(Console.ReadLine());
                        Console.Write("\nNhap Canh c");
                        double c1 = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("\nCanh a,b,c la:{0}, {1}, {2} ", a1, b1, c1);
                        Console.WriteLine("\nDien Tich Tam Giac la:{0} ", DienTichTamGiac(a1, b1, c1));
                        break;
                    default:
                        Chon = 4;
                        break;
                }

            } while (Chon != 4);

        }

        void menuPhepToanCoBan()
        {
            double a, b;
            Console.Write("Nhap so a: ");
            a = Convert.ToDouble(Console.ReadLine());
            Console.Write("Nhap so b: ");
            b = Convert.ToDouble(Console.ReadLine());

            char c;
            Console.Write("Nhap phep toan muon thuc hien( + - * / ) : ");
            c = Convert.ToChar(Console.ReadLine());
            switch (c)
            {
                case '+':
                    Console.WriteLine("Tong 2 so la: " + (a + b));
                    break;
                case '-':
                    Console.WriteLine("Hieu 2 so la: " + (a - b));
                    break;
                case '*':
                    Console.WriteLine("Tich 2 so la: " + (a * b));
                    break;
                case '/':
                    Console.WriteLine("Thuong 2 so la: " + (a / b));
                    break;
                default:
                    Console.WriteLine("Phep toan nhap khong dung!!");
                    break;
            }
        }
        void BangNhan()
        {
            int n;
            int s = 1;

            Console.Write("Nhap so can in bang nhan: ");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Bang nhan cua {0}: ", n);
            
            for(int i = 1; i < 10; i++)
            {
                s = n * i;
                Console.WriteLine(s);
            }
        }

        void tinhTongNSoLe()
        {
            int n;
            double sum = 0;
            Console.Write("Nhap so luong phan tu so le n: ");
            n = Convert.ToInt32(Console.ReadLine());

            int i = 1;
            Console.Write("Hien thi danh sach " + n + " so le la: ");
            //5
            while (i < n + 1)
            {
                int tmp = (2 * i - 1);
                Console.Write(" " + tmp);
                sum = sum + tmp;
                i++;
            }
            Console.WriteLine("\nTong so luong " + n + " so le la: " + sum);
            Console.ReadLine();
        }

        double giaithua(double n)
        {
            if (n == 1)
            {
                return 1;
            }
            else return giaithua(n - 1) * n;
        }

        void HelloWord()
        {
            Console.WriteLine("Hello World !!!");
        }

        void ChuyenKieu()
        {
            Console.WriteLine("----------------------------------");
            Console.WriteLine("Chuyen doi kieu du lieu trong c#");
            double d = 5678.74;
            int i;
            i = (int)d;
            Console.WriteLine("Gia tri cua i = " + i);
            Console.WriteLine("----------------------------------");
            Console.WriteLine("----------------------trang 16------------------");
            Console.WriteLine("Chuyen doi kieu du lieu trong c#");
            int i1 = 75;
            float f = 53.005f;
            double d1 = 2345.7652;
            bool b = true;
            Console.WriteLine(i1.ToString());
            Console.WriteLine(f.ToString());
            Console.WriteLine(d1.ToString());
            Console.WriteLine(b.ToString());
        }

        void khoitaobien()
        {
            Console.WriteLine("----------------------------------");
            Console.WriteLine("Khai bao va khoi tao bien trong c#");
            short a;
            int b2;
            double c;
            a = 10;
            b2 = 20;
            c = a + b2;
            Console.WriteLine("a = {0}, b = {1}, c = {2}", a, b2, c);
        }

        void Hang()
        {
            Console.WriteLine("----------------------------------");
            Console.WriteLine("Hang so trong c#");
            const double pi = 3.14159;
            double r;
            Console.Write("Nhap ban kinh: ");
            r = Convert.ToDouble(Console.ReadLine());
            double dien_tich = pi * r * r;
            Console.WriteLine("\n Ban kinh: {0}, dien tich {1}", r, dien_tich);
        }

        void CauDieuKienIf()
        {

            Console.WriteLine("Lenh if trong C#");
            Console.WriteLine("----------------");

            int a = 10;
            if (a < 20)
            {
                Console.WriteLine("a<20");
            }
            Console.WriteLine("Gia tri cua a la:{0}", a);

        }

        void CauDieuKienIf_else()
        {
            Console.WriteLine("Lenh if_else trong C#");
            Console.WriteLine("----------------");

            int a = 100;
            if (a > 20)
            {
                Console.WriteLine("a>20");
            }
            else
            {
                Console.WriteLine("a khong lon hon 20");
            }
            Console.WriteLine("Gia tri cua a la:{0}", a);
        }

        void CauDieuKienIfLong()
        {
            Console.WriteLine("Long cac lenh if trong C#");
            Console.WriteLine("----------------");

            int a = 100;
            int b = 200;

            if (a == 100)
            {
                if (b == 200)
                {
                    Console.WriteLine("Gia tri cua a la 100 va b la 200");
                }
            }

            Console.WriteLine("Gia tri cua a la:{0}", a);
            Console.WriteLine("Gia tri cua b la:{0}", b);
        }

        void VongLapWhile()
        {
            Console.WriteLine("Vong lap while trong C#");
            Console.WriteLine("-----------------------");
            int a = 10;
            while (a < 20)
            {
                Console.WriteLine("Gia tri cua A la:{0}", a);
                a++;
            }
        }

        void VongLapFor()
        {
            Console.WriteLine("Vong lap For trong C#");
            Console.WriteLine("---------------------");
            for (int a = 10; a < 20; a++)
            {
                Console.WriteLine("Gia tri cua a la: {0}", a);
            }
        }

        void VongLapDo_While()
        {
            Console.WriteLine("Vong lap do_while trong C#");
            Console.WriteLine("--------------------------");
            int a = 10;
            do
            {
                Console.WriteLine("Gia tri cua a la:{0}", a);
                a++;
            }
            while (a < 20);
        }

        void LongCacVonglap()
        {
            Console.WriteLine("Long Vong lap trong C#");
            Console.WriteLine("Tim so nguyen to trong C#");
            Console.WriteLine("----------------------");

            for (int i = 2; i < 100; i++)
            {
                for (int j = 2; j <= (i / j); j++)
                {
                    if ((i % j) == 0)
                        break;
                    if (j > (i / j))
                        Console.WriteLine("{0} la so nguyen to", i);
                }
            }
        }

        void LenhSwitch()
        {
            Console.WriteLine("Lenh Switch trong C#");
            Console.WriteLine("--------------------");
            char grade = 'B';
            switch (grade)
            {
                case 'A':
                    Console.WriteLine("Xuat Sac");
                    break;
                case 'B':
                case 'C':
                    Console.WriteLine("Gioi");
                    break;
                case 'D':
                    Console.WriteLine("Trung Binh");
                    break;
                case 'F':
                    Console.WriteLine("Hoc Lai");
                    break;
                default:
                    Console.WriteLine("Gia tri khong hop le");
                    break;
            }
            Console.WriteLine("Hoc luc cua ban la:{0}", grade);
        }

        void LongLenhSwitch()
        {
            Console.WriteLine("Long cac lenh switch trong C#");
            Console.WriteLine("-----------------------------");
            int a = 100;
            int b = 200;
            switch (a)
            {
                case 100:
                    Console.WriteLine("Dong nay thuoc lenh switch ben ngoai");
                    switch (b)
                    {
                        case 200:
                            Console.WriteLine("Dong nay thuoc lenh switch ben trong");
                            break;
                    }
                    break;
            }
            Console.WriteLine("Gia tri cua a la:{0}", a);
            Console.WriteLine("Gia tri cua b la:{0}", b);
        }

            static void Main(string[] args)
        {
            Program p = new Program();
            int key;
            do
            {
                Console.WriteLine("------------------------ MENU ------------------------");
                Console.WriteLine("| 1.Nhap 3 chu cai va hien thi theo chieu nguoc lai. |");
                Console.WriteLine("| 2.Kiem tra Username va Password.                   |");
                Console.WriteLine("| 3.Giai phuong trinh bac hai.                       |");
                Console.WriteLine("| 4.Tinh dien tich hinh tron, tam giac hoac chu nhat.|");
                Console.WriteLine("| 5.May tinh co ban.                                 |");
                Console.WriteLine("| 6.In bang nhan cua mot so.                         |");
                Console.WriteLine("| 7.Tinh tong n so le.                               |");
                Console.WriteLine("| 8.Tim giai thua cua mot so.                        |");
                Console.WriteLine("| 9.Hello World.                                     |");
                Console.WriteLine("| 10.Chuyen kieu.                                    |");
                Console.WriteLine("| 11.Khoi tao bien.                                  |");
                Console.WriteLine("| 12.Hang.                                           |");
                Console.WriteLine("| 13.Cau dieu kien IF.                               |");
                Console.WriteLine("| 14.Cau dieu kien IF ELSE.                          |");
                Console.WriteLine("| 15.Cau dieu kien IF long.                          |");
                Console.WriteLine("| 16.Vong lap WHILE.                                 |");
                Console.WriteLine("| 17.Vong lap FOR.                                   |");
                Console.WriteLine("| 18.Vong lap DO WHILE.                              |");
                Console.WriteLine("| 19.Long cac vong lap.                              |");
                Console.WriteLine("| 20.Lenh SWITCH.                                    |");
                Console.WriteLine("| 21.Long lenh SWITCH.                               |");
                Console.WriteLine("| 22.Exit.                                           |");
                Console.WriteLine("------------------------------------------------------");

                Console.Write("Nhap lua chon cua ban: ");
                key = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();

                switch (key)
                {
                    case 1:
                        p.chuoinguoc();
                        break;
                    case 2:
                        p.KiemtraPass();
                        break;
                    case 3:
                        p.giaiPhuongTrinhBac2();
                        break;
                    case 4:
                        p.menuDienTich();
                        break;
                    case 5:
                        p.menuPhepToanCoBan();
                        break;
                    case 6:
                        p.BangNhan();
                        break;
                    case 7:
                        p.tinhTongNSoLe();
                        break;
                    case 8:
                        int n = Convert.ToInt32(Console.ReadLine());
                        p.giaithua(n);
                        break;
                    case 9:
                        p.HelloWord();
                        break;
                    case 10:
                        p.ChuyenKieu();
                        break;
                    case 11:
                        p.Hang();
                        break;
                    case 12:
                        p.CauDieuKienIf();
                        break;
                    case 13:
                        p.CauDieuKienIf_else();
                        break;
                    case 14:
                        p.CauDieuKienIfLong();
                        break;
                    case 15:
                        p.VongLapWhile();
                        break;
                    case 16:
                        p.VongLapFor();
                        break;
                    case 17:
                        p.VongLapDo_While();
                        break;
                    case 18:
                        p.LongCacVonglap();
                        break;
                    case 19:
                        p.LenhSwitch();
                        break;
                    case 20:
                        p.LongLenhSwitch();
                        break;
                    case 21:
                        p.LongLenhSwitch();
                        break;
                    case 22:
                        break;
                    default:
                        Console.WriteLine("Lua chon cua ban khong thuoc MENU.");
                        Console.WriteLine("Vui long nhap lai.");
                        break;
                }

                Console.WriteLine();
            } while (key != 22);
        }
    }
}
