﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhanSo
{
    class PS
    {
        private int tu;
        private int mau;

        public PS() { }

        public PS(int tu, int mau)
        {
            this.tu = tu;
            this.mau = mau;
        }

        public void setTu(int tu)
        {
            this.tu=tu;
        }

        public void setMau(int mau)
        {
            this.mau=mau;
        }

        public int getTu()
        {
            return tu;
        }

        public int getMau()
        {
            return mau;
        }

        public void Xuat()
        {
            Console.WriteLine("{0}/{1}", this.tu, this.mau);
        }

        public PS Cong(PS a)
        {
            if (a.getMau() == this.mau)
            {
                return new PS(this.tu + a.getTu(), this.mau);
            }
            else
            {
                int t = (a.getTu() * this.mau);
                int tr = (this.mau * a.getMau());
                int b = a.getMau() * this.tu;
                int c = a.getMau() * this.mau;
                return new PS(b + t, c);

            }
        }
        public PS Tru(PS a)
        {
            if (a.getMau() == this.mau)
            {
                return new PS(this.tu - a.getTu(), this.mau);
            }
            else
            {
                int t = (a.getTu() * this.mau);
                int tr = (this.mau * a.getMau());
                int b = a.getMau() * this.tu;
                int c = a.getMau() * this.mau;
                return new PS(b - t, c);


            }
        }
        public PS Nhan(PS a)
        {
            return new PS(this.tu * a.getTu(), this.mau * a.getMau());
        }
        public PS Chia(PS a)
        {
            return new PS(this.tu * a.getMau(), this.mau * a.getTu());
        }
        

        public int UCLN(int a, int b)
        {
            if (a == 0 || b == 0) return 0; 

            int c;
            if (a < b)
            {
                c = a;
                a = b;
                b = c;
            }

            while (true)
            {
                c = a % b;
                if (c == 0) break;
                a = b;
                b = c;
            }

            return b;
        }

        public void KTPhanSoToiGian()
        {
            int soUCLN = UCLN(this.tu, this.mau);
            if (soUCLN == 1)
                Console.WriteLine("Da toi gian.");
            else
                Console.WriteLine("Chua toi gian.");
        }

        public PS PhanSoToiGian()
        {
            PS ts = new PS();
            int soUCLN = UCLN(this.tu, this.mau);
            ts.tu = this.tu / soUCLN;
            ts.mau = this.mau / soUCLN;
            return ts;
        }
    }
    internal class Program
    {
        static public void Menu(PS[] arr)
        {
            int choice = 0;
            do
            {
                Console.WriteLine();
                Console.WriteLine("1. Cong phan so.");
                Console.WriteLine("2. Tru phan so.");
                Console.WriteLine("3. Nhan phan so.");
                Console.WriteLine("4. Chia phan so.");
                Console.Write("Nhap lua chon: ");
                choice = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine();
                switch (choice)
                {
                    case 1:
                        PS cs, cs1 = new PS();
                        cs = arr[0];
                        for (int i = 1; i < arr.Length; i++)
                        {
                            cs = cs.Cong(arr[i]);
                        }
                        cs1 = cs.PhanSoToiGian();
                        cs1.Xuat();
                        break;
                    case 2:
                        PS ts, ts1 = new PS();
                        ts = arr[0];
                        for (int i = 1; i < arr.Length; i++)
                        {
                            ts = ts.Tru(arr[i]);
                        }
                        ts1 = ts.PhanSoToiGian();
                        ts1.Xuat();
                        break;
                    case 3:
                        PS ns, ns1 = new PS();
                        ns = arr[0];
                        for (int i = 1; i < arr.Length; i++)
                        {
                            ns = ns.Nhan(arr[i]);
                        }
                        ns1 = ns.PhanSoToiGian();
                        ns1.Xuat();
                        break;
                    case 4:
                        PS chs, chs1 = new PS();
                        chs = arr[0];
                        for (int i = 1; i < arr.Length; i++)
                        {
                            chs = chs.Chia(arr[i]);
                        }
                        chs1 = chs.PhanSoToiGian();
                        chs1.Xuat();
                        break;
                }
            } while (choice < 5 && choice > 0);

            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            PS[] arr;
            PS ps = new PS();
            int n, t, m, key;
            Console.Write("Nhap so luong phan so: ");
            n = Convert.ToInt32(Console.ReadLine());
            arr = new PS[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write("Tu so a{0}: ", i);
                t = Convert.ToInt32(Console.ReadLine());
                Console.Write("Mau so a{0}: ", i);
                m = Convert.ToInt32(Console.ReadLine());
                arr[i] = new PS(t, m);
            }
            do
            {
                Console.WriteLine("1. Cac pheo toan co ban.");
                Console.WriteLine("2. Kiem tra phan so to gian.");
                Console.WriteLine("3. Rut gon phan so.");
                Console.Write("nhap lua chon cua ban: ");
                key = Convert.ToInt32(Console.ReadLine());

                switch (key)
                {
                    case 1:
                        Menu(arr);
                        break;
                    case 2:
                        for(int i = 0; i < n; i++)
                        {
                            Console.Write("Phan so thu {0}: ", i + 1);
                            arr[i].KTPhanSoToiGian();
                        }
                        break;
                    case 3:
                        for(int i = 0; i < n; i++)
                        {
                            Console.Write("Rut gon phan so thu {0}: ", i + 1);
                            ps = arr[i].PhanSoToiGian();
                            ps.Xuat();
                        }
                        break;
                }

            } while (key > 0 && key < 4);

            Console.ReadKey();
        }
    }
}
