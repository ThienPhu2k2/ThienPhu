﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace VD_Buoi3
{
    internal class Program
    {
        // TINH KE THUA
        class HCN
        {
            protected double chieu_dai;
            protected double chieu_rong;

            public HCN(double l, double w)
            {
                chieu_dai = l; 
                chieu_rong = w;
            }

            public double tinhDienTich()
            {
                return chieu_dai * chieu_rong;
            }

            public void Display()
            {
                Console.WriteLine("Chieu dai: {0}", chieu_dai);
                Console.WriteLine("chieu rong: {0}", tinhDienTich());
            }
        }

        class ChiPhiXayDung : HCN
        {
            private double cost;

            public ChiPhiXayDung(double l, double w) : base(l, w) { }

            public double tinhChiPhi()
            {
                double chi_phi;
                chi_phi = tinhDienTich() * 70;
                return chi_phi;
            }

            public void HienThiThongTin()
            {
                base.Display();
                Console.WriteLine("Chi phi: {0}", tinhChiPhi());
            }
        }
        class Shape
        {
            protected int chieu_rong;
            protected int chieu_cao;
            public void setChieuRong(int w)
            {
                chieu_rong = w;
            }

            public void setChieuCao(int h)
            {
                chieu_cao = h;
            }
        }

        class Rectangle : Shape
        {
            public int tinhDientich()
            {
                return (chieu_cao * chieu_rong);
            }
        }

        public interface ChiPhiSon
        {
            int tinhChiPhi(int dien_tich);
        }

        class HinhChuNhat : Shape, ChiPhiSon
        {
            public int tinhDienTich()
            {
                return (chieu_rong * chieu_cao);
            }

            public int tinhChiPhi(int dien_tich)
            {
                return dien_tich * 70;
            }
        }

        // TINH DA HINH
        public class TestCsharp
        {
            void print(int i)
            {
                Console.WriteLine("In so nguyen: {0}", i);
            }

            void print(double f)
            {
                Console.WriteLine("In so thuc: {0}", f);
            }

            void print(string s)
            {
                Console.WriteLine("In chuoi: {0}", s);
            }

            public void mainTestCsharp()
            {
                TestCsharp p = new TestCsharp();

                p.print(5);
                p.print(500.263);
                p.print("Hoc C# co ban va nang cao");
            }
        }
        abstract class Hinh
        {
            public abstract int tinhDT();
        }

        class HinhCN : Hinh
        {
            private int chieu_dai;
            private int chieu_rong;

            public HinhCN(int a = 0, int b = 0)
            {
                chieu_dai = a;
                chieu_rong = b;
            }

            public override int tinhDT()
            {
                Console.WriteLine("Dien tich hinh chu nhat:");
                return (chieu_dai * chieu_rong);
            }
        }

        class ShapeDH
        {
            protected int chieu_rong, chieu_cao;

            public ShapeDH(int a = 0, int b = 0)
            {
                chieu_rong = a;
                chieu_cao = b;
            }

            public virtual int tinhDienTichDH()
            {
                Console.WriteLine("Dien tich cuar Class cha: ");
                return 0;
            }
        }

        class HinhChuNhatDH : ShapeDH
        {
            public HinhChuNhatDH(int a = 0, int b = 0) : base(a, b) { }

            public override int tinhDienTichDH()
            {
                Console.WriteLine("Dien tich cua Class HinhChuNhatDH: ");
                return (chieu_rong * chieu_cao);
            }
        }

        class TamGiac : ShapeDH
        {

            public TamGiac(int a = 0, int b = 0) : base(a, b) { }
            public override int tinhDienTichDH()
            {
                Console.WriteLine("Dien tich cuar Class TamGiac: ");
                return (chieu_cao * chieu_rong / 2);
            }
        }

        class HienTHiDuLieu
        {
            public void hienthiDienTich(ShapeDH sh)
            {
                int a;
                a = sh.tinhDienTichDH();
                Console.WriteLine("Dien tich: {0}", a);
            }
        }

        // NAP CHONG TOAN TU
        class Box
        {
            private double chieu_dai;
            private double chieu_rong;
            private double chieu_cao;

            public double tinhTheTich()
            {
                return chieu_dai * chieu_rong * chieu_cao;
            }

            public void setChieuDai(double len)
            {
                chieu_dai = len;
            }

            public void setChieuRong(double bre)
            {
                chieu_rong = bre;
            }

            public void setChieuCao(double hei)
            {
                chieu_cao = hei;
            }

            public static Box operator +(Box b, Box c)
            {
                Box box = new Box();
                box.chieu_dai = b.chieu_dai + c.chieu_dai;
                box.chieu_rong = b.chieu_rong + c.chieu_rong;
                box.chieu_cao = b.chieu_cao + c.chieu_cao;
                return box;
            }
        }

        //INTERFACE
        public interface GiaoDich
        {
            void hienThiThongTinGiaoDich();

            double laySoLuong();
        }

        class GiaoDichHangHoa : GiaoDich
        {
            private string ma_hang_hoa;
            private string ngay;
            private double so_luong;

            public GiaoDichHangHoa()
            {
                ma_hang_hoa = " ";
                ngay = " ";
                so_luong = 0.0;
            }

            public GiaoDichHangHoa(string ma_hang_hoa, string ngay, double so_luong)
            {
                this.ma_hang_hoa = ma_hang_hoa;
                this.ngay = ngay;
                this.so_luong = so_luong;
            }

            public double laySoLuong()
            {
                return so_luong;
            }

            public void hienThiThongTinGiaoDich()
            {
                Console.WriteLine("Ma hang hoa: {0}", ma_hang_hoa);
                Console.WriteLine("Ngay giao dich: {0}", ngay);
                Console.WriteLine("So luong: {0}", laySoLuong());
            }
        }

        static void Main(string[] args)
        {
            int key;
            do
            {
                Console.WriteLine("1. Tinh ke thua trong C#. ");
                Console.WriteLine("2. Tinh da hinh trong C#. ");
                Console.WriteLine("3. Nap chong toan tu trong C#. ");
                Console.WriteLine("4. Interface trong C#. ");
                Console.Write("Nhap lua chon cua ban: ");
                key = Convert.ToInt32(Console.ReadLine());

                switch (key)
                {
                    case 1:
                        Console.WriteLine("--------------------\n");
                        Console.WriteLine("Tinh ke thua tron C#");

                        Rectangle hcn = new Rectangle();

                        hcn.setChieuRong(5);
                        hcn.setChieuCao(7);

                        Console.WriteLine("Dien tich hinh chu nhat: {0}", hcn.tinhDientich());
                        Console.WriteLine("--------------------\n");

                        Console.WriteLine("--------------------\n");
                        Console.WriteLine("Tinh ke thua trong C#");
                        Console.WriteLine("Khoi tao lop co so");

                        ChiPhiXayDung t = new ChiPhiXayDung(4.5, 7.5);
                        t.HienThiThongTin();
                        Console.WriteLine("--------------------\n");

                        Console.WriteLine("-------------------------\n");
                        Console.WriteLine("Tinh ke thua trong C#");
                        Console.WriteLine("Vi du minh hoa da ke thua");

                        HinhChuNhat hinhchunhat = new HinhChuNhat();
                        int dien_tich;
                        hinhchunhat.setChieuRong(5);
                        hinhchunhat.setChieuCao(7);
                        dien_tich = hinhchunhat.tinhDienTich();

                        Console.WriteLine("Tong dien tich: {0}", hinhchunhat.tinhDienTich());
                        Console.WriteLine("Tong chi phi son: {0}", hinhchunhat.tinhChiPhi(dien_tich));
                        Console.WriteLine("--------------------\n");
                        break;
                    case 2:
                        Console.WriteLine("--------------------\n");
                        TestCsharp testCsharp = new TestCsharp();

                        testCsharp.mainTestCsharp();
                        Console.WriteLine("--------------------\n");

                        Console.WriteLine("--------------------\n");
                        Console.WriteLine("Tinh da hinh trong C#");
                        Console.WriteLine("Vi du minh hoa Da hinh dong");

                        HinhChuNhatDH r = new HinhChuNhatDH(10, 7);
                        double a = r.tinhDienTichDH();
                        Console.WriteLine("Dien tich: {0}", a);
                        Console.WriteLine("--------------------\n");

                        Console.WriteLine("--------------------\n");
                        Console.WriteLine("Tinh da hinh trong C#");
                        Console.WriteLine("Vi du minh hoa Da hinh dong");

                        HienTHiDuLieu c = new HienTHiDuLieu();
                        HinhChuNhatDH hinhChuNhatDH = new HinhChuNhatDH(10, 7);
                        TamGiac tamgiac = new TamGiac(10, 5);
                        c.hienthiDienTich(hinhChuNhatDH);
                        c.hienthiDienTich(tamgiac);
                        Console.WriteLine("--------------------\n");

                        break;
                    case 3:
                        Console.WriteLine("--------------------\n");
                        Console.WriteLine("Nap chong toan tu trong C#");
                        Console.WriteLine("Vi du minh hoa nap chong toan tu");

                        Box box1 = new Box();
                        Box box2 = new Box();
                        Box box3 = new Box();
                        double the_tich = 0.0;

                        box1.setChieuDai(6.0);
                        box1.setChieuRong(7.0);
                        box1.setChieuCao(5.0);

                        box2.setChieuDai(12.0);
                        box2.setChieuRong(13.0);
                        box2.setChieuCao(10.0);

                        the_tich = box1.tinhTheTich();
                        Console.WriteLine("The tich cua box1 la: {0}", the_tich);

                        the_tich = box2.tinhTheTich();
                        Console.WriteLine("The tich cua box2 la: {0}", the_tich);

                        box3 = box1 + box2;

                        the_tich = box3.tinhTheTich();
                        Console.WriteLine("The tich cua box3 la: {0}", the_tich);
                        Console.WriteLine("--------------------\n");
                        break;
                    case 4:
                        Console.WriteLine("--------------------\n");
                        Console.WriteLine("Interface trong C#");
                        Console.WriteLine("Vi du minh hoa interface");

                        GiaoDichHangHoa t1 = new GiaoDichHangHoa("001", "8/10/2012", 78900.00);
                        GiaoDichHangHoa t2 = new GiaoDichHangHoa("002", "9/10/2012", 451900.00);
                        t1.hienThiThongTinGiaoDich();
                        t2.hienThiThongTinGiaoDich();
                        Console.WriteLine("--------------------\n");
                        break;

                }
            } while (key > 0 && key < 5);
        }
    }
}
